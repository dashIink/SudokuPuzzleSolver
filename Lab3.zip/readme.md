This Sudoku Solver has no input method as none was specified in the document given to us. In fact, no deliverables were requested at all. 
This solver operates on the single example we were given as part of the document.

Currently, it uses 11 Threads to determine if the puzzle is valid, however can also function with only 3

Use Make to construct the file.
